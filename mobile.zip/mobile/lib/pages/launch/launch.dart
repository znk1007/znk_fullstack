import 'package:flutter/material.dart';

class LaunchScreen extends StatefulWidget {
  
  LaunchScreen({
    Key key, 
  }): super(
    key: key
  );

  _LaunchScreen createState() => _LaunchScreen();
  
}

class _LaunchScreen extends State<LaunchScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
  
}