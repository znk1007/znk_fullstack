import 'package:flutter/material.dart';

class BaseController extends StatefulWidget {
  BaseController({Key key}) : super(key: key);

  @override
  _BaseControllerState createState() => _BaseControllerState();
}

class _BaseControllerState extends State<BaseController> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Container(),
    );
  }
}