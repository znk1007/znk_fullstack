///
//  Generated code. Do not modify.
//  source: user.proto
//
// @dart = 2.3
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name,return_of_invalid_type

const User$json = const {
  '1': 'User',
  '2': const [
    const {'1': 'userId', '3': 1, '4': 1, '5': 9, '10': 'userId'},
    const {'1': 'sessionId', '3': 2, '4': 1, '5': 9, '10': 'sessionId'},
    const {'1': 'account', '3': 3, '4': 1, '5': 9, '10': 'account'},
    const {'1': 'nickname', '3': 4, '4': 1, '5': 9, '10': 'nickname'},
    const {'1': 'phone', '3': 5, '4': 1, '5': 9, '10': 'phone'},
    const {'1': 'email', '3': 6, '4': 1, '5': 9, '10': 'email'},
    const {'1': 'photo', '3': 7, '4': 1, '5': 9, '10': 'photo'},
    const {'1': 'createdAt', '3': 8, '4': 1, '5': 9, '10': 'createdAt'},
    const {'1': 'online', '3': 9, '4': 1, '5': 8, '10': 'online'},
  ],
};

